class Windows_factory {
public static button windowsButton()
{
    return new wb();
}  
public static checkbox windowsCheckbox()
{
    return  new wc();
}
public static redio windowsRedio()
{
    return new wr();
}
}
