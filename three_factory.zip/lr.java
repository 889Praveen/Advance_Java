 class lr implements redio {
    
    public String createredio()
    {
        return "linux redio....";
    }
}