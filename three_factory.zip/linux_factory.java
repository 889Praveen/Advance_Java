class linux_factory {
    public static button linuxButton()
    {
        return new lb();
    }  
    public static checkbox linuxCheckbox()
    {
        return  new lc();
    }
    public static redio linuxRedio()
    {
        return new lr();
    }
    }