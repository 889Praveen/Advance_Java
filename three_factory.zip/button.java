interface button
{
    public String createbutton();
}