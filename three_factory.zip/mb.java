class mb implements button {
    public String createbutton()
    {

      return "mac button...";
    }
   
}