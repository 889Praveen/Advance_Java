class lb implements button {
    public String createbutton()
    {
        return "linux button....";
    }
    
}
