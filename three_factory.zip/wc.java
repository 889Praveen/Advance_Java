class wc implements checkbox {
   
    public String createcheckbox()
    {
        return "Windows checkbox....";
    }
   
}