class wb implements button {
    public String createbutton()
    {
        return "Windows button....";
    }
}
