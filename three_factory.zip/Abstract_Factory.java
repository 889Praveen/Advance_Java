class Abstract_Factory {
public void getobject()
{
    Windows_factory.windowsButton();
    Windows_factory.windowsCheckbox();
    Windows_factory.windowsRedio();
}   
}
