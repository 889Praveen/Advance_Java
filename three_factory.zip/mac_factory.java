class mac_factory {
    public static button macButton()
    {
        return new mb();
    }  
    public static checkbox macCheckbox()
    {
        return  new mc();
    }
    public static redio macRedio()
    {
        return new mr();
    }
    }
