class linux_redio implements os_redio{
    public void createredio()
       {
        System.out.println("linux redio......");
       }

}
