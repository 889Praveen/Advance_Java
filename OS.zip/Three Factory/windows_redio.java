class windows_redio  implements os_redio{
      
        public void createredio()
        {
            System.out.println("windows redio....");
        }
    }