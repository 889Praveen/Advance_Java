class windows_button implements os_button{

   
    public void createbutton()
    {
       System.out.println("windows button....");
    }

    
}
