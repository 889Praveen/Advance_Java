 class mac_checkbox implements os_checkbox{
    
    
        public void createcheckboc() {
            System.out.println("mac  checkbox....."); }
       
    }
