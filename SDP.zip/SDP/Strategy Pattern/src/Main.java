public class Main {
    public static void main(String[] args) {
        SnakeStrategy snakeobj=new SnakeStrategy(new PoisonousSnake());
       snakeobj.snakeStrategy();
    }
}
