interface Snake
{
    void attack();
    
}