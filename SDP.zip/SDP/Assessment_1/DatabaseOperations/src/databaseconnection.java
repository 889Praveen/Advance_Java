import java.sql.Connection;

interface databaseconnection {

    public Connection connect();
    public void disconnect();
    public void query();
}
