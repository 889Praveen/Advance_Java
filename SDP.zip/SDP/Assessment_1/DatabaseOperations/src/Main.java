import java.sql.Connection;
import java.util.Scanner;
public class Main {
  
    public static void main(String[] args) {
       try
       {
        Scanner sc=new Scanner(System.in);
        
        while (true) {
            System.out.println("Enter Database Name:");
            String daString=sc.next().toLowerCase();
            databaseconnection data=Factorydatabase.getdatabasetype(daString);
            Connection con=data.connect();
            if(con == null)
            {
                System.out.println(""+daString+" Connection Not Found...");
                
            }
            data.query();
            data.disconnect();
    }
}catch(Exception e)
{ 
}
}
}