
interface Dessert {
    void serve();
}