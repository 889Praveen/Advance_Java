
    interface Appetizer {
        void prepare();
    }

