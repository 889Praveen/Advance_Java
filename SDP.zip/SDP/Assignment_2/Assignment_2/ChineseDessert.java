class ChineseDessert implements Dessert{
    public void serve() {
        System.out.println("Serving Chinese Dessert...");
    }
}
