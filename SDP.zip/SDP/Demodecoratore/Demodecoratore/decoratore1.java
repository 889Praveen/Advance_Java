package Demodecoratore;
class decoratore1 extends abdecoratore{

    public decoratore1(Componet object) {
        
        super(object);
    }
    // public void fistfeacher()
    // {
    //     System.out.println("addition fist.........!");
    // }
    @Override
    public void basicomponet() {
        
    super.abovemethodcoll();    
    System.out.println("addition fist.........!");
    }
    
    
    
   
  
}
