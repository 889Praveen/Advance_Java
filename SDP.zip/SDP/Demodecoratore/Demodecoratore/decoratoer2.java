package Demodecoratore;

class decoratoer2 extends abdecoratore {
    
    public decoratoer2(Componet objComponet)
    {
        super(objComponet);
    }
    
    // public void fistfeacher()
    // {
    //     System.out.println("addition fist.........!");
    // }

    @Override
    public void basicomponet() {
        super.abovemethodcoll();
        System.out.println("addition second.........!");
    }


}
