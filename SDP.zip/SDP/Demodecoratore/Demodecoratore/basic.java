package Demodecoratore;

 class basic implements Componet{

     public void basicomponet()
     {
        System.out.println("Bacic componet......!");
     }
}