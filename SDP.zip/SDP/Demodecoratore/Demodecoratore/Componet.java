package Demodecoratore;

interface Componet {
public void basicomponet();
    
}