public class Main {
    public static void main(String[] args) {
        try{
        proxy obj=new proxy("admin");
        obj.getfilepath("D:\\DEMO");
        obj.createfolder();
        }catch(Exception e)
        {
            e.printStackTrace();
        }
    }
}
