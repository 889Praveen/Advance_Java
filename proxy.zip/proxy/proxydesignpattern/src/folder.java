import java.io.File;

class folder implements filecreate{
   String file;
   boolean  created=false;
   String filepath;
   public folder(String filepath)
   {
            this.filepath=filepath;
   }
    @Override
    public void createfolder()
     {
        File folder=new File(filepath);
        if(!folder.exists())
        {
            created=folder.mkdir();
            if(created)
            {
                System.out.println("Folder Create Sucessfully....!");
            }
            else{
              System.out.println("Dose't not Create Folder...!");
            }

        }
        else{
        System.out.println("Folder Alredy created........!");
        }
    }
   
    
}
  

 