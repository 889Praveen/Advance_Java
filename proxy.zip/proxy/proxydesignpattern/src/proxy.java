 class proxy implements filecreate
 {
    String file;
    boolean fileobject=false;
    folder Folderobj;
    String filepath;
    public proxy(String obj)
    {
        file=obj;
    }

 public void getfilepath(String filepath)
 {
         this.filepath=filepath;
 }
    @Override
    public void createfolder() {
    if("admin".equals(file.toLowerCase()))
    {
        
        if(Folderobj==null)
        {
           Folderobj=new folder(filepath);   
        }
       Folderobj.createfolder();
    }
    else
    {
        System.out.println("File path doesn't match 'admin'. No folder created.!");
    }
}
   


 }