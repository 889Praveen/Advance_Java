interface filecreate {
public void createfolder();

    
}
