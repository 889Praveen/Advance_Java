import java.util.*;
public class Main {
    public static void main(String[] args) {
        Scanner sc =new Scanner(System.in);

        System.out.println("Enter cuisine Type like(Indian or Chinese)");
        String Cuisine=sc.next();
        AbstractFactory afobj=AbstractFactory.getFactory(Cuisine);

        Appetizers ap = afobj.getappetizers();
        System.out.println(ap.prepar());
        Desserts di=afobj.getdesserts();

        System.out.println(di.prepar()); 

        Maincourse mc = afobj.getMaincourse();
        System.out.println(mc.prepar());


    }
}
