public class IndianAppetizer implements Appetizers{
    public String prepar()
    {
        return "Samosa";
    }
}
