public interface Maincourse {
    public String prepar();
}
