public class ChineseMainCourse implements Maincourse{
    public String prepar()
    {
        return "Chow Mein";
    }
}
