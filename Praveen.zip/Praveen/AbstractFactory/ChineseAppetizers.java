public class ChineseAppetizers implements Appetizers{
    public String prepar()
    {
        return "Spring Rolls";
    }
}
