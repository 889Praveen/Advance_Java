import java.sql.Connection;

public class Main {
    public static void main(String[] args)throws Exception {
        DbConnection dbconn;
        dbconn = DbConnection.getInstance();
        Connection con = dbconn.connect();
        if(!con.isClosed())
         System.out.println("Connection is created");
    }
}
