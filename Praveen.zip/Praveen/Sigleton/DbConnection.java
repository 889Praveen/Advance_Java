
import java.sql.*;

public class DbConnection {
    private static DbConnection obj;
    private Connection con;

    private DbConnection() {
    }

    public synchronized Connection connect() throws Exception {
        if (con == null) {
      
            con = DriverManager.getConnection("jdbc:mysql://localhost:3306/sms", "root", "");
        }
        return con;
    }

    public synchronized static DbConnection getInstance() {
        if (obj == null) {
            obj = new DbConnection();
        }
        return obj;
    }
}
