interface WaterState {
    void applyHeat(Water water);
    void applyCold(Water water);
}