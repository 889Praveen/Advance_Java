class Water {
    private WaterState state;
    
    public Water() {
        this.state = new LiquidState(); 
    }
    
    public void setState(WaterState state) {
        this.state = state;
    }
    
    public void heat() {
        state.applyHeat(this);
    }
    
    public void cold() {
        state.applyCold(this);
    }
}