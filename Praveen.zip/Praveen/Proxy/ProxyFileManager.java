import java.io.IOException;

class ProxyFileManager implements IFileManager {
    private FileManager realFileOperations;
    private String role;

    public ProxyFileManager(String role) {
        this.role = role;
        this.realFileOperations = new FileManager();
    }

    @Override
    public boolean createFile(String directory, String fileName) throws IOException {
        if (role.equalsIgnoreCase("admin")) {
            realFileOperations.createFile(directory, fileName);
            return true;
        } else {
            throw new SecurityException("User role has no permission to create files");
        }
    
    }

    @Override
    public boolean writeToFile(String directory, String fileName, String content) throws IOException {
        if (role.equalsIgnoreCase("admin")) {
            realFileOperations.writeToFile(directory, fileName, content);
            return true;
        } else {
            throw new SecurityException("User role has no permission to write to files");
        }
    }

    @Override
    public String readFile(String directory, String fileName) throws IOException {
        return realFileOperations.readFile(directory, fileName);
    }

    @Override
    public boolean deleteFile(String directory, String fileName) throws IOException {
        if (role.equalsIgnoreCase("admin")) {
            realFileOperations.deleteFile(directory, fileName);
            return true;
        } else {
            throw new SecurityException("User role has no permission to delete files");
        }
    }
}
