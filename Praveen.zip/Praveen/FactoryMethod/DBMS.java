import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Iterator;
import java.util.Properties;

public abstract class DBMS {
    //Connection referrence variable contain reference of collection object
    Connection con;
    public DBMS() {
        con = null;
    }

    //connect method for  database connection 
    public abstract boolean connect(Properties p) throws SQLException;

    //selectRecords method select records from table
    public abstract ResultSet selectRecords(String table_name) throws SQLException;

    //close the database connection
    public boolean disconnect() throws SQLException {
        boolean re;
        con.close();
        if (con.isClosed())
            re = true;
        else
            re = false;
        con=null;
        return re;
    };
}