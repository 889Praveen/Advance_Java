import java.io.FileInputStream;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.Properties;
import java.util.Scanner;
import java.util.Set;
import java.util.Map;

public class Main {

    public static void main(String[] args) {

        Scanner s = new Scanner(System.in);
        // Properites to get data from file
        Properties p = new Properties();

        // Enter User database name
        System.out.println("Enter Database name you want to connect (MySql | Sqlite | Postgresql) :");
        String dbname = s.nextLine();

        FileInputStream fis;
        DBMS db;
        try {

            // connect to file
            fis = new FileInputStream("databaseurlfile.txt");

            // load file data into properties
            p.load(fis);

            // user enter database name approprite get database object
            db = DatabaseFactory.getDatabase(dbname);

            if (db.connect(p)) {
                try {
                    System.out.println("Connection to " + dbname);
                    // connection sucess after select records from student table
                    System.out.println("Enter  select Query  : ");
                    ResultSet rs = db.selectRecords(s.nextLine());
                    System.out.println(" ----------------------------------------- ");

                    // get metadata of result set
                    ResultSetMetaData rsd = rs.getMetaData();

                    // get number of column
                    int selected_column = rsd.getColumnCount();

                    // store columntype and columnname in array
                    String columnType[] = new String[selected_column];
                    String columnname[] = new String[selected_column];
                    for (int i = 1; i <= selected_column; i++) {
                        columnname[i - 1] = rsd.getColumnName(i);
                        columnType[i - 1] = rsd.getColumnTypeName(i);
                        // System.out.println(columnType[i-1]+" "+columnname[i-1]);
                    }

                    // get record one by one
                    while (rs.next()) {
                        for (int i = 0; i < columnType.length; i++) {
                            // get type of column and name from above array
                            // System.out.println(columnType[i]);
                            if (columnType[i].equals("INT"))
                                System.out.print(rs.getLong(columnname[i]) + " ");
                            else if (columnType[i].equals("VARCHAR") || columnType[i].equals("text"))
                                System.out.print(rs.getString(columnname[i]) + " ");

                        }
                        System.out.println();
                    }

                    System.out.println(" ----------------------------------------- ");
                } catch (Exception e) {
                    System.out.println("Error : " + e.getMessage());
                }
                // disconect to database
                if (db.disconnect()) {
                    System.out.println("Disconnect to " + dbname);
                }
            } else
                System.out.println("Not connected to database");

                fis.close();

        } catch (Exception e) {
            System.out.println("Error : " + e.getMessage());
            e.printStackTrace();
        } finally {

            s.close();
        }

    }
}
