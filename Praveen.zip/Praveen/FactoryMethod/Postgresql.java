import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Properties;

public class Postgresql extends DBMS{
    @Override
    public boolean connect(Properties p) throws SQLException {
        boolean re;
        con = DriverManager.getConnection(p.getProperty("Postgresql-url"),p.getProperty("Postgresql-user"),p.getProperty("Postgresql-password"));
        if (con == null)
            re = false;
        else
            re = true;
        return re;

    }
     @Override
     public ResultSet selectRecords(String query) throws SQLException {
  
        Statement st = con.createStatement();
  
        return st.executeQuery(query);
     }
}
