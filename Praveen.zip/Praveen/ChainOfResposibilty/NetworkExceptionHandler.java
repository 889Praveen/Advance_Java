class NetworkExceptionHandler extends ExceptionHandler {
    @Override
    public void handleException(Exception exception) {
        if (exception instanceof NetworkException) {
            System.out.println("Network Handler: Handling " + exception.getMessage());
            System.out.println("Action: Checking network connectivity...");
        } else if (nextHandler != null) {
            System.out.println("Network Handler: Passing to next handler...");
            nextHandler.handleException(exception);
        } else {
            System.out.println("Network Handler: No suitable handler found for " + exception.getMessage());
        }
    }
}