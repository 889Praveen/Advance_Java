class DefaultExceptionHandler extends ExceptionHandler {
    @Override
    public void handleException(Exception exception) {
        System.out.println("Default Handler: Handling uncaught exception - " + exception.getMessage());
        System.out.println("Action: Logging error and notifying system admin...");
    }
}