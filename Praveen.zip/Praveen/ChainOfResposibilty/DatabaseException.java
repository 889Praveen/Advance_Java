class DatabaseException extends Exception {
    public DatabaseException(String message) {
        super(message);
    }
}