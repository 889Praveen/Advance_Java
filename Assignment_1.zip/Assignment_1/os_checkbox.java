 interface os_checkbox {
public void createcheckboc();
    
} 