class linux_button implements os_button{

    public void createbutton()
    {
        System.out.println("linux button.....");
    }
   
}