interface os_button{
    public void createbutton();
    
}
