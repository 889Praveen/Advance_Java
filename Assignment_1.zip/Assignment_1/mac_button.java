class mac_button implements os_button{
    public void createbutton()
    {
        System.out.println("mac button....");
    }
   
}
