class linux_checkbox  implements os_checkbox{
  
    public void createcheckboc()
    {
        System.out.println("linux checkbox....");
    }
   
}
