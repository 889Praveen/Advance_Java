interface os_redio {
    public void createredio();
}
