interface MainCourse {
    void cook();
}