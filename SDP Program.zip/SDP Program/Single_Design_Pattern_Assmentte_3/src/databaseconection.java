

import java.sql.Connection;
import java.sql.DriverManager;

class databaseconection 
{
   static Connection conn=null;
private databaseconection()
{
   
    
}

public static databaseconection getdatabaseconnection() 
{
    try
    {
      if(conn == null )
      {
        synchronized(databaseconection.class){
         conn=DriverManager.getConnection("jdbc:mysql://localhost:3306/jdbc2025", "root","");
      }
   }
    }
    catch(Exception e)
    {
      //  e.printStackTrace();
    }
    return new databaseconection();
}
  
}