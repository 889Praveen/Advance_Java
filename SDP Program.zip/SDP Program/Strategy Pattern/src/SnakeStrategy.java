class SnakeStrategy {
    Snake snake;

    public SnakeStrategy(Snake snake)
    {
        this.snake=snake;
    }
    public void snakeStrategy()
    {
        this.snake.attack();
    }
}
