class PoisonousSnake implements Snake{

    @Override
    public void attack() {
        System.out.println("PoisonousSnake.......!");
    }

   
    
}
