class NonPoisonousSnake implements Snake{

    @Override
    public void attack() {
        System.out.println("NonPoisonousSnake.......!");
    }
}
