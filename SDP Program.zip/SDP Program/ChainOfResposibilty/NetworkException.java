class NetworkException extends Exception {
    public NetworkException(String message) {
        super(message);
    }
}