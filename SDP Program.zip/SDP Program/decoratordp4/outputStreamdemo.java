import java.io.FileWriter;
import java.io.IOException;

public class outputStreamdemo extends outputStreamDecorator {
    public int bytecount = 0;
    public int wordcount = 0;

    public outputStreamdemo(FileWriter ins) {
        super(ins);
    }

    public void write(String data) throws IOException {
        ins.write(data);
        char[] ar = data.toCharArray();
        int i = 1;
        while (i < ar.length) {
            if (ar[i] == ' ') {
                wordcount++;
            }
            bytecount++;
            i++;
        }

        bytecount++;
    }

    public void close() throws IOException {
        ins.close();
    }

    public int writeByteCount() {
        return bytecount;
    }

    public int writeWordCount() {
        return wordcount;
    }

}
