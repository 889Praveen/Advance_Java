import java.io.File;

class opretion implements fileopretion{
    




    public void createFolder(String folderName)
     {
        File folder = new File(folderName);
        if (folder.exists()) 
        {
            System.out.println("Folder already exists: " + folderName);
        }
         else 
        {
            boolean created = folder.mkdirs();
            if (created) {
                System.out.println("Folder created: " + folderName);
            } else {
                System.out.println("Failed to create folder: " + folderName);
            }
        }
    }

    @Override
    public void createfile(String filename) {
       File file=new  File(filename);
       if (file.exists()) {
           
       }
    }





}
