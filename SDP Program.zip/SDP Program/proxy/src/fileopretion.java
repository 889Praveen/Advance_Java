
public interface fileopretion {
    void createFolder(String path);
    void createfile(String filename);
}
