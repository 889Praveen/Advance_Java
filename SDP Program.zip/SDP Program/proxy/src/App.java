public class App {
    public static void main(String[] args) throws Exception {
        
        proxy py=new proxy("admin");
        py.createFolder("D:\\Praveen");
    }
}
