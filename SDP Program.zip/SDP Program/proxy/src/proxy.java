class proxy implements fileopretion{
    
    String name;
   public proxy(String name)
{
 
    this.name=name;

}


   @Override
   public void createFolder(String path) {
    if (this.name.equalsIgnoreCase("admin"))
     {
        opretion obj=new opretion();
        obj.createFolder(path);
    }
    else
    {
        System.out.println("only Admin Access.!");
    }
   }}
