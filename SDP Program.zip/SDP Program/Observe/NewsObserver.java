
public interface NewsObserver {
    void update(String news);
}
