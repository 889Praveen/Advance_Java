interface checkbox
{
    public String createcheckbox();
}