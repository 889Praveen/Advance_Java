class Windows_factory {
public static    
}
