interface redio {
public String createredio();
    
}