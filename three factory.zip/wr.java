 class wr implements redio{
 public String createredio()
 {
    return "Windows redio....";
 }
}
    