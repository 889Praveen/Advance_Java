class mc implements checkbox{
    
    public String createcheckbox()
    {
      return "mac checkbox....";
    }
    
}