class mac_factory {
public static     
}
