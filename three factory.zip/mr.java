class mr implements redio {
   
    public String createredio()
    {
        return "mac redio....";
    }
}
