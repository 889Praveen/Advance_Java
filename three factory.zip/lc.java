 class lc implements checkbox {
    
    public String createcheckbox()
    {
        return "linux checkbox....";
    }
    
}