class ChineseAppetizer implements Appetizer{
    public void prepare() 
    {
        System.out.println("Preparing Chinese Appetizer...");
    }
}
