abstract class AbstractFactory 
{
    abstract MainCourse createMainCourse();
    abstract Appetizer createAppetizer();
    abstract Dessert createDessert();
   
        public static AbstractFactory getcountries(String countrytype)
        {
            AbstractFactory var=null;
            switch(countrytype)
            {
              case "Indian":
                            var=new IndianCuisineFactory();
                            break;
          case "Chinese":
                            var=new  ChineseCuisineFactory();
                            break;
          default:
                        
                        break;
        }
        return var; 
    }
    
}
