public class Main {
    public static void main(String[] args) {

        AbstractFactory indianFactory = AbstractFactory.getcountries("Chinese");

        MainCourse mc=indianFactory.createMainCourse();
        Appetizer ap=indianFactory.createAppetizer();
        Dessert de=indianFactory.createDessert();
        mc.cook();
        ap.prepare();
        de.serve();
       
        

    }
    
}
