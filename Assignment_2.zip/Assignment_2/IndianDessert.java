public class IndianDessert implements Dessert{
    public void serve() {
        System.out.println("Serving Indian Dessert...");
    }
}
