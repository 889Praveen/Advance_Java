class ChineseMainCourse implements MainCourse {
    public void cook() {
        System.out.println("Cooking Chinese Main Course...");
    } 
}
