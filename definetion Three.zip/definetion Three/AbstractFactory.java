interface AbstractFactory {
    MainCourse createMainCourse();
    Appetizer createAppetizer();
    Dessert createDessert();
}
