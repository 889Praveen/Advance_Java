class IndianMainCoursep implements MainCourse{
    public void cook() {
        System.out.println("Cooking Indian Main Course...");
    }
}
